package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.wear.compose.material.Icon
import androidx.wear.compose.material.Stepper
import androidx.wear.compose.material.StepperDefaults
import androidx.wear.compose.material.Text

@Composable
fun StepperEx(){
    var value by remember { mutableStateOf(5) }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Stepper(
            value = value,
            onValueChange = {value=it},
            increaseIcon = { Icon(StepperDefaults.Increase,"Increase") },
            decreaseIcon = { Icon(StepperDefaults.Decrease,"Decrease")},
            valueProgression = 0..10,
        ){ Text("value:$value")}
    }
}