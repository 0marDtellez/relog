package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.CircularProgressIndicator

@Composable
fun CircularProgressEx(){
    CircularProgressIndicator(
        modifier = Modifier
            .fillMaxSize()
            .padding(all=1.dp),
        startAngle = 295.5f,
        endAngle = 245.5f,
        progress = 0.3f,
        strokeWidth = 5.dp,
        indicatorColor = Color.Blue,
        trackColor = Color.LightGray
    )
}