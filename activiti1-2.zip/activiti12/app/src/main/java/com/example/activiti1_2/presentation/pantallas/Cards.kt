package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.Card
import androidx.wear.compose.material.Text
import com.example.activiti1_2.R

@Composable
fun CardEx(){
    val log= painterResource(R.drawable._49995)
    Column(
        Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            onClick = { /*TODO*/ },
            modifier = Modifier.fillMaxWidth(),
            contentColor = Color.Yellow,
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = log,
                    contentDescription ="logo",
                    Modifier.size(24.dp)
                )
                    Text("jetpack Compose!", textAlign = TextAlign.Center)

            }
        }
    }
}