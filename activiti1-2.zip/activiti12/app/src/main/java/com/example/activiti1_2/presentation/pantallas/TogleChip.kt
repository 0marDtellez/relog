package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.*
import com.example.activiti1_2.R

@Composable
fun TogleChip(){
    val logit= painterResource(R.drawable.sanji)
    val logos= painterResource(R.drawable.telefono)
    var checked by remember { mutableStateOf(true) }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ToggleChip(
            label ={
                Text(
                    text = "Sanji!",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            secondaryLabel = {
                Text(
                    text ="Compose wear OS!",
                    maxLines =1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            checked = checked,
            colors = ToggleChipDefaults.toggleChipColors(
                uncheckedToggleControlColor = ToggleChipDefaults.SwitchUncheckedIconColor
            ),
            toggleControl = {
                Switch(
                    checked =checked,
                    enabled =true,
                    modifier = Modifier.semantics {
                        this.contentDescription=
                            if (checked) "Oh" else "Off"
                    }
                )
            },
            onCheckedChange = {checked=it},
            appIcon = {
                Icon(
                    painter =logos,
                    contentDescription ="call",
                    modifier = Modifier
                        .size(24.dp)
                        .wrapContentSize(align = Alignment.Center)
                )
            },
            enabled = true,
        )
    }
}