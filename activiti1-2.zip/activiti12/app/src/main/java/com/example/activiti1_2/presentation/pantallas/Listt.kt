package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.*

@Composable
fun ListEx(){
    val listState= rememberScalingLazyListState()
    val list:List<String> =
    listOf("Maras","Antep","Izmir","Istanbul","Ankara","Mardin","Rize")
    Column(
        Modifier.fillMaxSize()
    ) {
      ScalingLazyColumn(state = listState){
          itemsIndexed(items = list){index, item ->  
              Card(
                  onClick = { /*TODO*/ },
                  modifier = Modifier.fillMaxWidth(),
                  contentColor = Color.Black,
                  shape = RoundedCornerShape(20.dp)
              ) {
                  Column(
                      Modifier.fillMaxSize(),
                      horizontalAlignment = Alignment.CenterHorizontally,
                      verticalArrangement = Arrangement.Center
                  ) {
                      Text(item, textAlign = TextAlign.Center, color = Color.Yellow)
                  }
              }
              Spacer(modifier = Modifier.height(8.dp))
          }
      }  
    }
}