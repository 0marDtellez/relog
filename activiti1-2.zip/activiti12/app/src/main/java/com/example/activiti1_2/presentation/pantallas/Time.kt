package com.example.activiti1_2.presentation.pantallas

import android.text.format.DateFormat
import androidx.compose.runtime.*
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.material.TimeTextDefaults
import java.util.*

@Composable
fun TiemTextEx(){
    TimeText(
        timeSource = TimeTextDefaults.timeSource(
            DateFormat.getBestDateTimePattern(Locale.getDefault(),"yyyy-MM-dd-hh:mm")
        )
    )
}