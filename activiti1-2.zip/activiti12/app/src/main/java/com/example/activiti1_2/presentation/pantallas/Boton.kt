package com.example.activiti1_2.presentation.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.*
import com.example.activiti1_2.presentation.theme.Activiti12Theme

@Composable
fun ButsitoExample(){
    val logo= painterResource(com.example.activiti1_2.R.drawable.telefono)
    Activiti12Theme{
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { /*TODO*/ },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green)
            ) {
                Icon(
                    painter = logo,
                    contentDescription ="Telefono",
                    Modifier.size(24.dp)
                )
            }
        }
    }
}
